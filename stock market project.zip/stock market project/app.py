from flask import Flask, render_template, request
import requests


app = Flask(__name__)


def fetch_symbols():
    old_url = 'https://www.nseindia.com/option-chain'
    url = "https://www.nseindia.com/api/master-quote"
    session = requests.Session()

    session.headers.update({
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, '
                          'like Gecko) Chrome/80.0.3987.149 Safari/537.36',
    })
    try:
        m = session.get(old_url, timeout=60)
        cookies = m.cookies
        r = session.get(url, timeout=60, cookies=cookies)

        r.raise_for_status()
        data = r.json()
        return {"data": data, "cookies": cookies}

    except Exception as e:
        print(f"Unable to get the symbols. This error occurred: {e}")
        return None


def fetch_symbol_data(symbol='AARTIIND', expiry_date=None, cookies=None):
    url = f"https://www.nseindia.com/api/option-chain-equities?symbol={symbol}"
    if symbol == "M&M":
        url = f"https://www.nseindia.com/api/option-chain-equities?symbol=M%26M"
    if symbol == "M&MFIN":
        url = f"https://www.nseindia.com/api/option-chain-equities?symbol=M%26MFIN"
    session = requests.Session()

    session.headers.update({
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, '
                          'like Gecko) Chrome/80.0.3987.149 Safari/537.36',
    })
    try:
        r = session.get(url, timeout=60, cookies=cookies)

        r.raise_for_status()
        data = r.json()
        result = clean_data(data, expiry_date)
        return result

    except Exception as e:
        print(f"Please try after some time. This error occurred: {e}")
        return None


def fetch_nifty_data(contract='NIFTY', expiry_date=None, cookies=None):
    url = f'https://www.nseindia.com/api/option-chain-indices?symbol={contract}'
    session = requests.Session()

    session.headers.update({
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, '
                          'like Gecko) Chrome/80.0.3987.149 Safari/537.36',
    })
    try:
        r = session.get(url, timeout=60, cookies=cookies)

        r.raise_for_status()
        data = r.json()
        result = clean_data(data, expiry_date)
        return result

    except Exception as e:
        print(f"Please try after some time. This error occurred: {e}")
        return None


def clean_data(data, expiry_date):
        records_data = data.get('records', {}).get('data', [])
        expiry_dates = data.get('records', {}).get('expiryDates', [])

        # Filter data by selected expiry date if provided
        if expiry_date:
            if expiry_date not in expiry_dates:
                expiry_date = expiry_dates[0]
        else:
            expiry_date = expiry_dates[0]
        records_data = [record for record in records_data if record.get('expiryDate') == expiry_date]

        combined_data = []
        pe_total = 0
        ce_total = 0
        pe_volume_total = 0
        ce_volume_total = 0

        for index, record in enumerate(records_data):
            pe_data = record.get('PE', {})
            ce_data = record.get('CE', {})

            put_oi_ltp_value = (int(pe_data.get('openInterest', 0)) * float(pe_data.get('lastPrice', 0.0))) if pe_data else 0
            call_oi_ltp_value = (int(ce_data.get('openInterest', 0)) * float(ce_data.get('lastPrice', 0.0))) if ce_data else 0
            put_volume_ltp_value = (int(pe_data.get('totalTradedVolume', 0)) * float(pe_data.get('lastPrice', 0.0))) if pe_data else 0
            call_volume_ltp_value = (int(ce_data.get('totalTradedVolume', 0)) * float(ce_data.get('lastPrice', 0.0))) if ce_data else 0

            pe_total += put_oi_ltp_value
            ce_total += call_oi_ltp_value
            pe_volume_total += put_volume_ltp_value
            ce_volume_total += call_volume_ltp_value

            combined_data.append({
                'strikePrice': record.get('strikePrice', 'N/A'),
                'expiryDate': record.get('expiryDate', 'N/A'),
                'pe_openInterest': pe_data.get('openInterest', 'N/A'),
                'pe_lastPrice': pe_data.get('lastPrice', 'N/A'),
                'pe_volume': pe_data.get('totalTradedVolume', 'N/A'),
                'put_oi_ltp_value': put_oi_ltp_value,
                'put_volume_ltp_value': put_volume_ltp_value,
                'ce_openInterest': ce_data.get('openInterest', 'N/A'),
                'ce_lastPrice': ce_data.get('lastPrice', 'N/A'),
                'ce_volume': ce_data.get('totalTradedVolume', 'N/A'),
                'call_oi_ltp_value': call_oi_ltp_value,
                'call_volume_ltp_value': call_volume_ltp_value,
            })

        result = {
            'combined_data': combined_data,
            'pe_total': pe_total,
            'ce_total': ce_total,
            'pe_volume_total': pe_volume_total,
            'ce_volume_total': ce_volume_total,
            'expiry_dates': expiry_dates,
            'selected_expiry': expiry_date
        }
        return result



@app.route('/')
@app.route('/index')
def index():
    symbols = fetch_symbols()
    contract = request.args.get('contract', 'NIFTY')
    expiry_date = request.args.get('expiry_date')
    if symbols:
        data = fetch_nifty_data(contract, expiry_date, symbols['cookies'])

    if data is not None:
        data['contract'] = contract
        data['symbols'] = symbols['data']
        return render_template('index.html', **data)
    else:
        error = "The Api have some rate limit So Please try after 2-3 minutes..."
        dictionary = {
            'error': error,
            'pe_total': 0,
            'ce_total': 0,
            'pe_volume_total': 0,
            'ce_volume_total': 0,
            'contract': contract,
            'selected_expiry': expiry_date
        }
        return render_template('index.html', **dictionary)


@app.route('/symbol')
def symbol_data():
    symbols = fetch_symbols()
    symbol = request.args.get('symbol', 'AARTIIND')
    expiry_date = request.args.get('expiry_date')
    if symbols:
        data = fetch_symbol_data(symbol, expiry_date, symbols['cookies'])
    if data is not None:
        data['symbol'] = symbol
        data['symbols'] = symbols['data']
        return render_template('index.html', **data)
    else:
        error = "The Api have some rate limit So Please try after 2-3 minutes..."
        dictionary = {
            'error': error,
            'pe_total': 0,
            'ce_total': 0,
            'pe_volume_total': 0,
            'ce_volume_total': 0,
            'symbol': symbol,
            'selected_expiry': expiry_date
        }
        return render_template('index.html', **dictionary)


# Custom 404 error handler
@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404


if __name__ == "__main__":
    app.run(debug=True, host='0.0.0.0', threaded=True)